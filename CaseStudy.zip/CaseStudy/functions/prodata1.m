function [Sigma_pr, Sigma_pst, nu_pr, nu_pst, Kn, nvar]=prodata1(D,Y1,...
    ny, sdz, lag)

if nargin == 4; lag = 0; end

[T,nx] = size(D);
if sdz == 1
    D = (D - ones(T,1)*nanmean(D))./(ones(T,1)*nanstd(D));
    Y1 = (Y1 - ones(T,1)*nanmean(Y1))./(ones(T,1)*nanstd(Y1));
else
    D = (D - ones(T,1)*nanmean(D));
    Y1 = (Y1 - ones(T,1)*nanmean(Y1));
end
if lag ~= 0
    X=D;
    nexp = size(X,2);   %���ͱ������ܸ���
    nvar = nexp + 1;
    nu_pr = nvar + 1;
    nu_pst = nu_pr + T;
    Sigma_pr = cell(1,ny);
    Sigma_pst = cell(1,ny);
    for i = 1:ny
        D = [X,Y1(:,i)]; 
        %S_hat = D'*D;
        S_hat = T.*nancov(D);
        Sigma_pr{i} = eye(size(S_hat,2));
        Sigma_pst{i} = (S_hat + nu_pr.*Sigma_pr{i})./(nu_pst);
    end
    
else
    X = [D,Y1];
    nexp = size(X,2) -1; 
    nvar = nexp + 1;
    nu_pr = nvar + 1;
    nu_pst = nu_pr + T;
    D = X; 
    S_hat = D'*D;
    Sigma_pr = eye(size(S_hat,2));
    Sigma_pst = (S_hat + nu_pr.*Sigma_pr)./(nu_pst);
end

Kn   = zeros(nvar,1);
for j = 1:nvar
    aux =  -0.5*(j*T)*log(pi);
    num = 0;         den = 0;     
    for i = 1:j
        num = num + gammaln((nu_pst + 1 - i)/2);
        den = den + gammaln((nu_pr + 1 - i)/2);
    end
    Kn(j) = aux + num - den ;
end